import {archiveFrames} from './archive.js';
import {FINAL_HOLD_START} from './timing.js';

export function attachExportControls({render, pause, finish, clearReference, renderer, poster, stage, status, ribbons, shadow, finalSurface}) {
function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

function captureScene(milliseconds) {
  render(milliseconds);
  return {
    milliseconds,
    shadowOpacity: shadow.material.opacity,
    ribbons: ribbons.map(ribbon => {
      const geometry = ribbon.backing.mesh.geometry;
      return {
        name: ribbon.name, color: ribbon.color,
        position: Array.from(geometry.attributes.position.array),
        halfWidths: Array.from(geometry.attributes.halfWidth.array),
        index: Array.from(geometry.index.array),
        columns: ribbon.backing.columns, extent: ribbon.backing.extent,
        sourceMix: ribbon.backing.mesh.material.uniforms.sourceMix.value,
        surfaceMix: finalSurface.material.opacity,
      };
    }),
  };
}

document.getElementById('export-scene').addEventListener('click', () => {
  pause();
  const samples = [0, 200, 400, 600, 750, 850, 900, 1000].map(captureScene);
  download(new Blob([JSON.stringify({units: 'reference-image pixels', camera: 'orthographic +Z, 2560 square', samples})], {type: 'application/json'}), 'woven-v2-scene.json');
  finish();
});

document.getElementById('export-master').addEventListener('click', async event => {
  const button = event.currentTarget;
  button.disabled = true;
  pause();
  clearReference();
  const size = 1600;
  renderer.setPixelRatio(1);
  renderer.setSize(size, size, false);
  const master = document.createElement('canvas');
  master.width = master.height = size;
  const context = master.getContext('2d');
  const frames = [];
  try {
    for (let index = 0; index < 60; index++) {
      const time = index * 1000 / 60;
      render(time);
      context.clearRect(0, 0, size, size);
      context.fillStyle = '#D9C9B2';
      context.fillRect(0, 0, size, size);
      if (time >= FINAL_HOLD_START) context.drawImage(poster, size / 4, size / 4, size / 2, size / 2);
      else context.drawImage(renderer.domElement, 0, 0, size, size);
      const blob = await new Promise(resolve => master.toBlob(resolve, 'image/png'));
      frames.push({name: `frame-${String(index).padStart(3, '0')}.png`, bytes: new Uint8Array(await blob.arrayBuffer())});
      status.textContent = `Exporting master frame ${index + 1} / 60`;
    }
    download(archiveFrames(frames), 'woven-v2-master-1600-60fps.zip');
    status.textContent = '60 lossless master frames exported';
  } catch (error) {
    status.textContent = `Export failed: ${String(error)}`;
  } finally {
    button.disabled = false;
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    renderer.setSize(stage.clientWidth * 2, stage.clientWidth * 2, false);
    finish();
  }
});

}
