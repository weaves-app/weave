import * as THREE from '../assets/vendor/three.module.js';
import {DURATION, CHOREOGRAPHY_DURATION, FINAL_HOLD_START, SIZE, smooth} from './timing.js';
import {ribbons} from './ribbon-paths.js';
import {sourceLayers} from './source-textures.js';
import {buildBacking, updateRibbon} from './ribbon-mesh.js';
import {attachExportControls} from './export-preview.js';
const stage = document.getElementById('art-stage');
const poster = document.getElementById('art');
const status = document.getElementById('motion-status');
const progress = document.getElementById('motion-progress');
const replay = document.getElementById('motion-replay');
const toggle = document.getElementById('motion-toggle');
const finalButton = document.getElementById('motion-still');
const referenceButton = document.getElementById('motion-reference');
const reducePreview = document.getElementById('motion-reduce');
const timeLabel = document.getElementById('motion-time');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let elapsed = 0;
let playing = false;
let frame = 0;
let startedAt = 0;
let startElapsed = 0;
let referenceVisible = false;
let playbackRate = 1;
let renderer;
const reduce = () => reduced.matches || reducePreview.checked;

const scene = new THREE.Scene();
const camera = new THREE.OrthographicCamera(-1280, 1280, 1280, -1280, 0.1, 4000);
camera.position.z = 2000;

let shadow;
let finalSurface;
const finalScene = new THREE.Scene();
function buildFinalSurface() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 1600;
  const context = canvas.getContext('2d');
  context.fillStyle = '#D9C9B2';
  context.fillRect(0, 0, 1600, 1600);
  context.drawImage(poster, 400, 400, 800, 800);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.MeshBasicMaterial({map: texture, transparent: true, opacity: 0, depthTest: false, depthWrite: false, toneMapped: false});
  finalSurface = new THREE.Mesh(new THREE.PlaneGeometry(2560, 2560), material);
  finalScene.add(finalSurface);
}

function render(milliseconds) {
  elapsed = Math.max(0, Math.min(DURATION, milliseconds));
  if (!renderer) return;
  const choreographyTime = elapsed / DURATION * CHOREOGRAPHY_DURATION;
  for (const ribbon of ribbons) updateRibbon(ribbon, choreographyTime);
  shadow.material.opacity = smooth((choreographyTime - 650) / 4300);
  renderer.autoClear = true;
  renderer.render(scene, camera);
  // Blend opaque composites instead of fading two transparent ribbon layers.
  // The latter exposes the background and briefly washes out the artwork.
  finalSurface.material.opacity = smooth((elapsed - 752) / 128);
  renderer.autoClear = false;
  renderer.render(finalScene, camera);
  // Traced ribbons seat first; a short surface blend restores the source detail.
  // The immutable poster holds the exact approved artwork after the motion.
  const complete = elapsed >= FINAL_HOLD_START;
  poster.hidden = !complete && !referenceVisible;
  renderer.domElement.hidden = complete || referenceVisible;
  progress.value = String(Math.round(elapsed));
  timeLabel.textContent = `${(elapsed / 1000).toFixed(1)} / 1.0 s`;
  stage.dataset.progress = String(Math.round(elapsed));
  stage.dataset.state = complete ? 'complete' : playing ? 'playing' : 'paused';
  if (referenceVisible) status.textContent = 'The original selected artwork';
  else if (playing) status.textContent = choreographyTime < 1900 ? 'Threads converge from every side' : choreographyTime < 3960 ? 'Over, under, together' : choreographyTime < 5700 ? 'Bind the center' : 'Settle into the original weave';
}
function pause() {
  playing = false;
  cancelAnimationFrame(frame);
  toggle.textContent = 'Play';
}
function finish() {
  pause();
  referenceVisible = false;
  referenceButton.setAttribute('aria-pressed', 'false');
  render(DURATION);
  status.textContent = reduce() ? 'Reduced motion · original artwork' : 'Original artwork · holds still';
}
function tick(now) {
  if (!playing) return;
  if (!startedAt) startedAt = now;
  render(startElapsed + (now - startedAt) * playbackRate);
  if (elapsed >= DURATION) finish();
  else frame = requestAnimationFrame(tick);
}
function play(restart = false) {
  pause();
  if (reduce()) { finish(); return; }
  referenceVisible = false;
  referenceButton.setAttribute('aria-pressed', 'false');
  if (restart || elapsed >= DURATION) elapsed = 0;
  playing = true;
  startedAt = 0;
  startElapsed = elapsed;
  toggle.textContent = 'Pause';
  frame = requestAnimationFrame(tick);
}
function changePreference() {
  for (const control of [progress, replay, toggle]) control.disabled = reduce();
  if (reduce()) finish();
  else status.textContent = elapsed >= DURATION ? 'Original artwork · holds still' : 'Paused · inspect the weave';
}
replay.addEventListener('click', () => { playbackRate = 1; play(true); });
document.getElementById('motion-slow').addEventListener('click', () => { playbackRate = 0.2; play(true); });
toggle.addEventListener('click', () => { if (playing) { pause(); status.textContent = 'Paused'; } else play(); });
finalButton.addEventListener('click', finish);
referenceButton.addEventListener('click', () => {
  pause();
  referenceVisible = !referenceVisible;
  referenceButton.setAttribute('aria-pressed', String(referenceVisible));
  render(elapsed);
  if (!referenceVisible) status.textContent = 'Paused · inspect the weave';
});
progress.addEventListener('input', () => {
  pause(); referenceVisible = false;
  referenceButton.setAttribute('aria-pressed', 'false');
  render(Number(progress.value)); status.textContent = elapsed >= FINAL_HOLD_START ? 'Original artwork · holds still' : 'Paused · inspect the weave';
});
reducePreview.addEventListener('change', changePreference);
reduced.addEventListener('change', changePreference);

async function initialize() {
  await poster.decode();
  renderer = new THREE.WebGLRenderer({alpha: true, antialias: true, powerPreference: 'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.setClearColor('#D9C9B2', 1);
  renderer.domElement.className = 'woven-canvas';
  renderer.domElement.setAttribute('aria-hidden', 'true');
  stage.append(renderer.domElement);
  // Guides were traced against the original natural-size image, padded to 1280.
  // Normalize the complete scene once, including its origin, to the poster box.
  const sourceScale = SIZE / poster.naturalWidth;
  scene.scale.set(sourceScale, sourceScale, 1);
  scene.position.set((SIZE - poster.naturalWidth) * sourceScale / 2, -(SIZE - poster.naturalHeight) * sourceScale / 2, 0);
  const textures = sourceLayers(poster);
  for (const ribbon of ribbons) {
    ribbon.backing = buildBacking(scene, ribbon, textures[ribbon.index]);
  }
  shadow = new THREE.Mesh(new THREE.PlaneGeometry(SIZE, SIZE), new THREE.MeshBasicMaterial({map: textures[7], transparent: true, depthWrite: false, toneMapped: false}));
  scene.add(shadow);
  buildFinalSurface();
  const resize = () => {
    renderer.setSize(stage.clientWidth * 2, stage.clientWidth * 2, false);
    render(elapsed);
  };
  const observer = new ResizeObserver(resize);
  observer.observe(stage);
  document.addEventListener('visibilitychange', () => { if (document.hidden && playing) finish(); });
  renderer.domElement.addEventListener('webglcontextlost', event => {
    event.preventDefault(); pause(); poster.hidden = false; renderer.domElement.hidden = true;
    status.textContent = 'Showing the original artwork';
  });
  window.addEventListener('pagehide', () => { pause(); observer.disconnect(); renderer.dispose(); }, {once: true});
  attachExportControls({render, pause, finish, clearReference: () => {referenceVisible = false;}, renderer, poster, stage, status, ribbons, shadow, finalSurface});
  resize();
  changePreference();
  if (document.hidden || reduce()) finish();
  else play(true);
}
initialize().catch(error => {
  pause();
  poster.hidden = false;
  if (renderer) renderer.domElement.hidden = true;
  status.textContent = 'Showing the original artwork';
  console.error('Artwork motion unavailable', error);
});

