import * as THREE from '../assets/vendor/three.module.js';
import {SIZE} from './timing.js';
import {ribbons} from './ribbon-paths.js';
function sourceLayers(poster) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = SIZE;
  const context = canvas.getContext('2d', {willReadFrequently: true});
  context.drawImage(poster, 0, 0);
  const original = context.getImageData(0, 0, SIZE, SIZE);
  const images = Array.from({length: 8}, () => context.createImageData(SIZE, SIZE));
  // A coarse nearest-curve lookup avoids scanning every curve for every pixel.
  const stride = 8;
  const cells = SIZE / stride;
  const distances = ribbons.map(ribbon => {
    const field = new Float32Array(cells * cells);
    for (let y = 0; y < cells; y++) for (let x = 0; x < cells; x++) {
      field[y * cells + x] = ribbon.nearest(x * stride + stride / 2, y * stride + stride / 2).distance;
    }
    return field;
  });
  for (let y = 0; y < SIZE; y++) for (let x = 0; x < SIZE; x++) {
    const offset = (y * SIZE + x) * 4;
    const r = original.data[offset];
    const g = original.data[offset + 1];
    const b = original.data[offset + 2];
    const a = original.data[offset + 3];
    if (!a) continue;
    const cell = Math.floor(y / stride) * cells + Math.floor(x / stride);
    let layer;
    if (a < 220 && y > 920 && r + g + b < 320) {
      layer = 7;
    } else if (r - g > 27 && g - b > 20 && x > 520 && x < 802 && y > 460 && y < 733) {
      layer = 6;
    } else {
      const candidates = r - g > 4 ? [4, 5] : [0, 1, 2, 3];
      layer = candidates.reduce((best, id) => distances[id][cell] < distances[best][cell] ? id : best);
    }
    images[layer].data.set(original.data.subarray(offset, offset + 4), offset);
  }
  for (const ribbon of ribbons) {
    const depths = Array.from({length: 241}, (_, i) => {
      const point = ribbon.at(i / 240 * ribbon.length);
      const offset = (Math.round(point.y) * SIZE + Math.round(point.x)) * 4;
      return images[ribbon.index].data[offset + 3] > 120 ? 32 : -32;
    });
    ribbon.depths = depths.map((_, i) => {
      let total = 0;
      for (let j = -5; j <= 5; j++) total += depths[Math.max(0, Math.min(240, i + j))];
      return total / 11;
    });
  }
  return images.map(data => {
    const layer = document.createElement('canvas');
    layer.width = layer.height = SIZE;
    layer.getContext('2d').putImageData(data, 0, 0);
    const texture = new THREE.CanvasTexture(layer);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.generateMipmaps = false;
    texture.minFilter = THREE.LinearFilter;
    return texture;
  });
}

function completeThreadTexture(ribbon) {
  // Reconstruct occluded lengths as one matte surface. Repeating fragments of
  // the still would repeat its overlap shadows and make the entrance look torn.
  const width = 384;
  const height = 96;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  const pixels = context.createImageData(width, height);
  const base = ribbon.index < 4 ? [123, 130, 108] : ribbon.index < 6 ? [224, 215, 198] : [200, 134, 95];
  let seed = 1837 + ribbon.index;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const across = y / (height - 1);
    const along = x / (width - 1);
    const face = 0.96 + 0.055 * Math.sin(across * Math.PI) - 0.055 * across;
    const edge = across < 0.045 ? 0.86 + across * 3 : across > 0.91 ? 0.94 - (across - 0.91) * 2.2 : 1;
    const light = 0.91 + 0.07 * Math.sin(along * Math.PI * 2 + ribbon.index * 0.7);
    seed = (1664525 * seed + 1013904223) >>> 0;
    const grain = ((seed >>> 24) / 255 - 0.5) * 4;
    const offset = (y * width + x) * 4;
    for (let channel = 0; channel < 3; channel++) pixels.data[offset + channel] = base[channel] * face * edge * light + grain;
    pixels.data[offset + 3] = 255;
  }
  context.putImageData(pixels, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}


export {sourceLayers, completeThreadTexture};
