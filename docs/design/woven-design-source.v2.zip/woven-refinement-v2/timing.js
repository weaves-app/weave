const DURATION = 1000;
const CHOREOGRAPHY_DURATION = 6800;
const FINAL_HOLD_START = 900;
const SIZE = 1280;
const clamp = x => Math.max(0, Math.min(1, x));
const smooth = x => { const t = clamp(x); return t * t * t * (t * (t * 6 - 15) + 10); };

export {DURATION, CHOREOGRAPHY_DURATION, FINAL_HOLD_START, SIZE, clamp, smooth};
