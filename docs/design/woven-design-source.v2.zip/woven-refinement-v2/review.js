const video = document.getElementById('review-video');
const progress = document.getElementById('review-progress');
const time = document.getElementById('review-time');
const status = document.getElementById('review-status');
const current = document.getElementById('review-new');
const previous = document.getElementById('review-old');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let version = 'Refined';
let animationFrame;

function update() {
  progress.value = String(Math.round(video.currentTime * 1000));
  time.textContent = `${video.currentTime.toFixed(1)} / 1.0 s`;
  if (!video.paused) animationFrame = requestAnimationFrame(update);
}

async function replay(rate = 1) {
  cancelAnimationFrame(animationFrame);
  if (reduced.matches) {
    video.hidden = true;
    status.textContent = 'Reduced motion · original artwork';
    return;
  }
  video.hidden = false;
  video.currentTime = 0;
  video.playbackRate = rate;
  status.textContent = `${version} · ${rate === 1 ? 'one second' : 'slow motion for inspection'}`;
  try {
    await video.play();
    update();
  } catch {
    video.hidden = true;
    status.textContent = 'Original artwork · preview unavailable';
  }
}

function select(useCurrent) {
  version = useCurrent ? 'Refined' : 'Previous';
  current.setAttribute('aria-pressed', String(useCurrent));
  previous.setAttribute('aria-pressed', String(!useCurrent));
  video.src = useCurrent ? 'woven-refinement-v2/intro.v2.preview.mp4' : 'woven-refinement-v2/intro.v1.reference.mp4';
  replay();
}
current.addEventListener('click', () => select(true));
previous.addEventListener('click', () => select(false));
document.getElementById('review-replay').addEventListener('click', () => replay());
document.getElementById('review-slow').addEventListener('click', () => replay(0.2));
progress.addEventListener('input', () => {
  video.pause();
  video.currentTime = Number(progress.value) / 1000;
  update();
  status.textContent = `${version} · paused`;
});
video.addEventListener('ended', () => {
  update();
  status.textContent = `${version} · original artwork holds`;
});
reduced.addEventListener('change', () => {
  if (reduced.matches) { video.pause(); video.hidden = true; }
});
replay();
