"""Public S07 frame-sequence regression: the last 100 ms must hold still.

Use decoded or lossless 60-frame PNGs; compression tolerance is <1 code value.
This detects late visual changes, not subjective animation quality.
"""
import json
from pathlib import Path
import sys
import numpy as np
from PIL import Image

paths = sorted(Path(sys.argv[1]).glob('frame-*.png'))
assert len(paths) == 60, f'Expected 60 frames, got {len(paths)}'
frames = [np.asarray(Image.open(p).convert('RGB'), dtype=float) for p in paths]
height, width, _ = frames[0].shape
crop = (slice(height // 4, 3 * height // 4), slice(width // 4, 3 * width // 4))
changes = [float(np.abs(b[crop] - a[crop]).mean()) for a, b in zip(frames, frames[1:])]
late_max = max(changes[-5:])
report = {'scenario': 'S07', 'frames': len(paths), 'last_100ms_mean_changes': changes[-5:],
          'maximum_late_change': late_max, 'allowed_mean_change': 0.75,
          'last_frame_change': changes[-1], 'passes': late_max <= 0.75}
print(json.dumps(report, indent=2))
assert report['passes'], 'S07: visible artwork is still changing during the final 100 ms hold'
