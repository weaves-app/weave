import * as THREE from '../assets/vendor/three.module.js';
import {SIZE, clamp, smooth} from './timing.js';
import {threadPoint} from './ribbon-paths.js';
import {completeThreadTexture} from './source-textures.js';
function buildBacking(scene, ribbon, sourceTexture) {
  const segments = 280;
  const columns = 12;
  const extent = 195;
  const pad = 100;
  const count = (segments + 1) * (columns + 1);
  const positions = new Float32Array(count * 3);
  const uvs = new Float32Array(count * 2);
  const sourceUvs = new Float32Array(count * 2);
  const halfWidths = new Float32Array(count);
  const indices = [];
  for (let i = 0; i <= segments; i++) for (let j = 0; j <= columns; j++) {
    const vertex = i * (columns + 1) + j;
    const along = -pad + i / segments * (ribbon.length + 2 * pad);
    const source = ribbon.at(along);
    const normal = (j / columns * 2 - 1) * extent;
    uvs[vertex * 2] = i / segments;
    uvs[vertex * 2 + 1] = j / columns;
    sourceUvs[vertex * 2] = (source.x - source.ty * normal) / SIZE;
    sourceUvs[vertex * 2 + 1] = 1 - (source.y + source.tx * normal) / SIZE;
    if (i < segments && j < columns) {
      const a = vertex;
      const b = a + columns + 1;
      indices.push(a, b, a + 1, a + 1, b, b + 1);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geometry.setAttribute('sourceUv', new THREE.BufferAttribute(sourceUvs, 2));
  geometry.setAttribute('halfWidth', new THREE.BufferAttribute(halfWidths, 1));
  geometry.setIndex(indices);
  const material = new THREE.ShaderMaterial({
    transparent: true, depthWrite: true, side: THREE.DoubleSide, toneMapped: false,
    uniforms: {
      threadTexture: {value: completeThreadTexture(ribbon)},
      sourceTexture: {value: sourceTexture},
      sourceMix: {value: 0},
      layerOpacity: {value: 1},
      extent: {value: extent},
    },
    vertexShader: `
      attribute vec2 sourceUv;
      attribute float halfWidth;
      varying vec2 vUv;
      varying vec2 vSourceUv;
      varying float vHalfWidth;
      void main() {
        vUv = uv;
        vSourceUv = sourceUv;
        vHalfWidth = halfWidth;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D threadTexture;
      uniform sampler2D sourceTexture;
      uniform float sourceMix;
      uniform float layerOpacity;
      uniform float extent;
      varying vec2 vUv;
      varying vec2 vSourceUv;
      varying float vHalfWidth;
      void main() {
        float normal = (vUv.y * 2.0 - 1.0) * extent;
        float bodyAlpha = (1.0 - smoothstep(vHalfWidth - 0.65, vHalfWidth + 0.65, abs(normal))) * step(0.5, vHalfWidth);
        vec2 bodyUv = vec2(vUv.x, normal / max(1.0, vHalfWidth * 2.0) + 0.5);
        vec4 body = texture2D(threadTexture, bodyUv);
        vec4 source = texture2D(sourceTexture, vSourceUv);
        if (vSourceUv.x < 0.0 || vSourceUv.x > 1.0 || vSourceUv.y < 0.0 || vSourceUv.y > 1.0) source.a = 0.0;
        float a = bodyAlpha * (1.0 - sourceMix) + source.a * sourceMix;
        if (a < 0.002) discard;
        vec3 color = (body.rgb * bodyAlpha * (1.0 - sourceMix) + source.rgb * source.a * sourceMix) / max(a, 0.001);
        gl_FragColor = vec4(color, a * layerOpacity);
        #include <colorspace_fragment>
      }
    `,
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.frustumCulled = false;
  mesh.renderOrder = 1 + ribbon.index;
  scene.add(mesh);
  return {mesh, segments, columns, extent, pad};
}

function updateRibbon(ribbon, milliseconds) {
  const linear = clamp((milliseconds - ribbon.start) / ribbon.duration);
  const travel = smooth(linear);
  const head = -ribbon.feedLength + (ribbon.feedLength + ribbon.length) * travel;
  const tail = head - ribbon.length;
  // Restore the source shading on the SAME moving surface, avoiding a double
  // silhouette. A final, stationary pixel pass only closes any sampling seams.
  const sourceMix = smooth((linear - 0.82) / 0.18);
  const backing = ribbon.backing;
  backing.mesh.visible = linear > 0;
  backing.mesh.material.uniforms.sourceMix.value = sourceMix;
  backing.mesh.material.uniforms.layerOpacity.value = 1;
  backing.mesh.material.depthWrite = sourceMix < 0.01;
  backing.mesh.material.depthTest = sourceMix < 0.01;
  const positions = backing.mesh.geometry.attributes.position;
  const halfWidths = backing.mesh.geometry.attributes.halfWidth;
  const widthSettled = smooth((linear - 0.7) / 0.3);
  for (let i = 0; i <= backing.segments; i++) {
    const sourceDistance = -backing.pad + i / backing.segments * (ribbon.length + backing.pad * 2);
    const distance = tail + sourceDistance;
    const center = threadPoint(ribbon, distance);
    if (sourceDistance < 0 || sourceDistance > ribbon.length) {
      const target = ribbon.at(sourceDistance);
      const align = smooth((linear - 0.85) / 0.15);
      center.x += (target.x - center.x) * align;
      center.y += (target.y - center.y) * align;
      center.tx += (target.tx - center.tx) * align;
      center.ty += (target.ty - center.ty) * align;
    }
    const feedingWidth = 0.2 + 0.8 * smooth((distance + 50) / 340);
    const idealWidth = ribbon.width * (feedingWidth + (1 - feedingWidth) * widthSettled);
    const previous = threadPoint(ribbon, distance - 8);
    const next = threadPoint(ribbon, distance + 8);
    const curvature = Math.abs(Math.atan2(previous.tx * next.ty - previous.ty * next.tx, previous.tx * next.tx + previous.ty * next.ty)) / 16;
    const width = Math.min(idealWidth, 1.65 / Math.max(curvature, 0.0001));
    const depthIndex = Math.max(0, Math.min(239.99, distance / ribbon.length * 240));
    const depthA = Math.floor(depthIndex);
    const depth = ribbon.index === 6 ? 64 : distance < 0 ? ribbon.index * 0.1 : ribbon.depths[depthA] + (ribbon.depths[depthA + 1] - ribbon.depths[depthA]) * (depthIndex - depthA);
    const endRound = Math.sqrt(Math.max(0, Math.min(1, sourceDistance / 18, (ribbon.length - sourceDistance) / (18 + 46 * (1 - widthSettled)))));
    for (let j = 0; j <= backing.columns; j++) {
      const normal = (j / backing.columns * 2 - 1) * backing.extent;
      const x = center.x - center.ty * normal;
      const y = center.y + center.tx * normal;
      const vertex = i * (backing.columns + 1) + j;
      positions.setXYZ(vertex, x - 640, 640 - y, depth);
      halfWidths.setX(vertex, width * endRound * 0.5);
    }
  }
  positions.needsUpdate = true;
  halfWidths.needsUpdate = true;
}


export {buildBacking, updateRibbon};
