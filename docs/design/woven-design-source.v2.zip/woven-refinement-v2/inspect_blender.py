"""Import sampled ribbon geometry into Blender for structural inspection.

This is a geometry study, not the camera-projected final artwork renderer.
Run: blender --background --python inspect_blender.py -- scene.json output-dir
"""
import json
from pathlib import Path
import sys
import bpy
import numpy as np

args = sys.argv[sys.argv.index('--') + 1:]
data = json.loads(Path(args[0]).read_text())
out = Path(args[1]).resolve()
out.mkdir(parents=True, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.render.fps = 60
scene.frame_start = 1
scene.frame_end = 61
scene.unit_settings.system = 'NONE'
scene['reference_units'] = '128 reference pixels = 1 Blender unit'
scene['purpose'] = 'Sampled geometry inspection; approved texture projection is authored in Three.js'

def ribbon_vertices(ribbon):
    """Convert shader half-widths into actual geometry for solid viewport review."""
    raw = np.array(ribbon['position'], dtype=float).reshape(-1, ribbon['columns'] + 1, 3)
    widths = np.array(ribbon['halfWidths']).reshape(-1, ribbon['columns'] + 1)[:, 0]
    centers = raw[:, ribbon['columns'] // 2, :]
    direction = raw[:, -1, :] - raw[:, 0, :]
    direction /= np.maximum(np.linalg.norm(direction, axis=1)[:, None], 1e-9)
    across = np.linspace(-1, 1, ribbon['columns'] + 1)
    return ((centers[:, None, :] + direction[:, None, :] * widths[:, None, None] * across[None, :, None]) / 128).reshape(-1, 3)

report = {'blender': bpy.app.version_string, 'purpose': scene['purpose'], 'samples': [], 'meshes': []}
objects = []
for index, ribbon in enumerate(data['samples'][0]['ribbons']):
    vertices = ribbon_vertices(ribbon)
    faces = np.array(ribbon['index']).reshape(-1, 3).tolist()
    mesh = bpy.data.meshes.new(ribbon['name'])
    mesh.from_pydata(vertices.tolist(), [], faces)
    mesh.update()
    obj = bpy.data.objects.new(ribbon['name'], mesh)
    scene.collection.objects.link(obj)
    rgb = tuple(int(ribbon['color'][i:i+2], 16) / 255 for i in (1, 3, 5))
    material = bpy.data.materials.new(ribbon['name'] + ' inspection material')
    material.diffuse_color = (*rgb, 1)
    obj.data.materials.append(material)
    obj.shape_key_add(name='Basis')
    for sample_index, sample in enumerate(data['samples']):
        coords = ribbon_vertices(sample['ribbons'][index])
        key = obj.shape_key_add(name=f"{sample['milliseconds']} ms")
        key.data.foreach_set('co', coords.ravel())
        f = 1 + sample['milliseconds'] * 60 / 1000
        if sample_index > 0:
            key.value = 0
            previous = 1 + data['samples'][sample_index - 1]['milliseconds'] * 60 / 1000
            key.keyframe_insert(data_path='value', frame=previous)
        key.value = 1
        key.keyframe_insert(data_path='value', frame=f)
        if sample_index < len(data['samples']) - 1:
            key.value = 0
            following = 1 + data['samples'][sample_index + 1]['milliseconds'] * 60 / 1000
            key.keyframe_insert(data_path='value', frame=following)
    objects.append(obj)
    report['meshes'].append({'name': obj.name, 'vertices': len(mesh.vertices), 'triangles': len(faces), 'parent': None, 'armature': False})

for sample in data['samples']:
    sample_report = {'milliseconds': sample['milliseconds'], 'shadowOpacity': sample['shadowOpacity'], 'ribbons': []}
    for r in sample['ribbons']:
        vertices = ribbon_vertices(r)
        assert np.isfinite(vertices).all(), f"Nonfinite geometry: {r['name']}"
        sample_report['ribbons'].append({'name': r['name'], 'bounds_min': vertices.min(axis=0).tolist(), 'bounds_max': vertices.max(axis=0).tolist(), 'max_half_width_px': max(r['halfWidths'])})
    report['samples'].append(sample_report)

camera_data = bpy.data.cameras.new('Reference orthographic camera')
camera = bpy.data.objects.new('Reference orthographic camera', camera_data)
scene.collection.objects.link(camera)
camera.location = (0, 0, 20)
camera_data.type = 'ORTHO'
camera_data.ortho_scale = 20
scene.camera = camera
for sample in data['samples']:
    scene.timeline_markers.new(f"{sample['milliseconds']} ms sample", frame=round(1 + sample['milliseconds'] * 60 / 1000))
scene.frame_set(52)
scene.render.engine = 'BLENDER_WORKBENCH'
scene.display.shading.light = 'STUDIO'
scene.display.shading.color_type = 'MATERIAL'
scene.render.resolution_x = 1000
scene.render.resolution_y = 1000
scene.render.resolution_percentage = 100
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type == 'VIEW_3D':
            area.spaces.active.region_3d.view_perspective = 'CAMERA'
report['finiteGeometry'] = True
report['meshCount'] = len(objects)
(out / 'blender-inspection.json').write_text(json.dumps(report, indent=2) + '\n')
bpy.ops.wm.save_as_mainfile(filepath=str(out / 'woven-geometry-study.blend'))
print(json.dumps({'saved': str(out / 'woven-geometry-study.blend'), 'meshes': len(objects), 'finiteGeometry': True}))
