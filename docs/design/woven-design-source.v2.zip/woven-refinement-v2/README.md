# Woven refinement preview

Open `review.html` through the parent visualization server (port 4318). Compare **Refined**, **Previous**, **Replay** and **Slow motion**. The user approved this preview for production on 2026-10-09; the application serves the identical clip as intro.v2.mp4.

`index.html` is the reproducible authoring/export view. Geometry, texture extraction, mesh updates, preview controls and export helpers have separate modules. The unchanged reference image and vendored Three.js remain in the parent `assets` folder.

The original image is 1254 square; the historical trace grid is 1280 square. The scene normalizes both scale and origin before export. The final opaque composite restores the exact approved artwork without the brightness loss of cross-fading transparent layers. The movement completes within the 60-frame, one-second clip and the final 100 ms holds still.

Blender is used to inspect the sampled geometry, not to render this preview. `inspect_blender.py` imports `scene.json` into seven editable meshes and records coordinates/bounds/shadow progression in `blender/blender-inspection.json`. The saved `.blend` is a sampled geometry study, not a physical cloth simulation; interpolated poses between recorded samples are approximations.

Run `check_frames.py` against exported frame PNGs with Python/Pillow/NumPy to check the final hold. Baseline RED and candidate GREEN are recorded under the WEA-24 feature evidence. Numerical checks supplement visual review. Existing texture reconstruction can still be inspected in slow motion; the original cross-browser/device matrix remains a separate release gate.

Export scene JSON with the authoring view’s geometry export control. Run `blender --background --python woven-refinement-v2/inspect_blender.py -- path/to/exported-scene.json path/to/output` to regenerate the inspection and sampled .blend. Generated scene JSON, .blend files and master PNG frames are intentionally excluded; the scripts reproduce them.
