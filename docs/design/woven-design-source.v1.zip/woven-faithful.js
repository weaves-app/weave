import * as THREE from './assets/vendor/three.module.js';

// Continuous ribbons arrive from edges and corners along traced weaving routes.
// Their leading ends pull the trailing lengths through each curve.
// The selected source artwork supplies the final finish and reduced-motion state.
const DURATION = 1000;
const CHOREOGRAPHY_DURATION = 6800;
const SIZE = 1280;
const stage = document.getElementById('art-stage');
const poster = document.getElementById('art');
const status = document.getElementById('motion-status');
const progress = document.getElementById('motion-progress');
const replay = document.getElementById('motion-replay');
const toggle = document.getElementById('motion-toggle');
const finalButton = document.getElementById('motion-still');
const referenceButton = document.getElementById('motion-reference');
const reducePreview = document.getElementById('motion-reduce');
const timeLabel = document.getElementById('motion-time');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const clamp = x => Math.max(0, Math.min(1, x));
const smooth = x => { const t = clamp(x); return t * t * t * (t * (t * 6 - 15) + 10); };
let elapsed = 0;
let playing = false;
let frame = 0;
let startedAt = 0;
let startElapsed = 0;
let referenceVisible = false;
let renderer;
const reduce = () => reduced.matches || reducePreview.checked;

// Guides are authored in the approved 1280 × 1280 image coordinate system.
// Their asymmetric curves and returned ends belong to the original sculpture.
const definitions = [
  { name: 'Olive upper cross-thread', color: '#737a61', width: 144, start: 0, duration: 3400,
    points: [[125,634],[216,636],[354,518],[470,464],[573,388],[671,307]] },
  { name: 'Olive upper down-thread', color: '#737a61', width: 143, start: 230, duration: 3650,
    points: [[596,124],[640,204],[744,288],[804,410],[855,531],[959,639],[1005,727],[977,764]] },
  { name: 'Olive lower down-thread', color: '#747b61', width: 143, start: 440, duration: 3640,
    points: [[366,570],[420,637],[511,766],[602,919],[701,1010],[755,1086],[720,1123]] },
  { name: 'Olive lower cross-thread', color: '#757d63', width: 141, start: 680, duration: 3660,
    points: [[1159,553],[1117,630],[965,738],[818,808],[661,865],[553,921],[529,972],[574,1003]] },
  { name: 'Ivory descending thread', color: '#ded3bd', width: 164, start: 1080, duration: 3720,
    points: [[365,386],[356,322],[420,310],[523,407],[611,529],[701,661],[818,804],[916,914],[986,938]] },
  { name: 'Ivory returning thread', color: '#ded3bd', width: 160, start: 1480, duration: 3690,
    points: [[503,965],[412,951],[342,885],[357,816],[486,725],[634,631],[798,514],[936,403],[965,354],[928,335]] },
  { name: 'Terracotta binding', color: '#bd7954', width: 124, start: 3960, duration: 2080,
    points: [[611,673],[586,620],[628,581],[684,548],[728,548],[753,580]] },
];

function trace(points) {
  const curve = new THREE.CatmullRomCurve3(points.map(([x, y]) => new THREE.Vector3(x, y, 0)), false, 'centripetal');
  const samples = curve.getSpacedPoints(240);
  const length = curve.getLength();
  function at(distance) {
    const t = distance / length;
    if (t < 0 || t > 1) {
      const end = t < 0 ? 0 : samples.length - 1;
      const adjacent = t < 0 ? 1 : samples.length - 2;
      const direction = samples[end].clone().sub(samples[adjacent]).normalize();
      const extension = t < 0 ? -distance : distance - length;
      const point = samples[end].clone().addScaledVector(direction, extension);
      return { x: point.x, y: point.y, tx: t < 0 ? -direction.x : direction.x, ty: t < 0 ? -direction.y : direction.y };
    }
    const index = Math.min(samples.length - 2, Math.floor(t * (samples.length - 1)));
    const fraction = t * (samples.length - 1) - index;
    const a = samples[index];
    const b = samples[index + 1];
    const d = Math.hypot(b.x - a.x, b.y - a.y);
    return {x: a.x + (b.x - a.x) * fraction, y: a.y + (b.y - a.y) * fraction, tx: (b.x - a.x) / d, ty: (b.y - a.y) / d};
  }
  function nearest(x, y) {
    let distance = Infinity;
    let index = 0;
    for (let j = 0; j < samples.length; j++) {
      const p = samples[j];
      const d = (p.x - x) ** 2 + (p.y - y) ** 2;
      if (d < distance) { distance = d; index = j; }
    }
    return {distance, along: index / (samples.length - 1) * length};
  }
  return {at, nearest, length};
}
// Feed each end from the edge that naturally continues its final tangent.
// Reversing traversal changes the entrance, not the final ribbon geometry.
definitions[2].points.reverse();
definitions[4].points.reverse();
definitions[5].points.reverse();
const entrances = [
  {side: 'left', origin: [-520, 640], handle: [-110, 625]},
  {side: 'top', origin: [565, -520], handle: [550, -110]},
  {side: 'bottom', origin: [695, 1800], handle: [705, 1400]},
  {side: 'right', origin: [1800, 550], handle: [1420, 565]},
  {side: 'bottom-right', origin: [1770, 1740], handle: [1350, 1230]},
  {side: 'top-right', origin: [1720, -480], handle: [1230, 25]},
  {side: 'top-left', origin: [-480, -450], handle: [130, 190]},
];
const starts = [0, 70, 120, 180, 240, 310, 2180];
const durations = [4800, 4850, 4800, 4750, 4790, 4800, 3460];
const ribbons = definitions.map((definition, index) => ({...definition, index, start: starts[index], duration: durations[index], ...trace(definition.points)}));

for (const ribbon of ribbons) {
  const first = ribbon.at(0);
  const entrance = entrances[ribbon.index];
  const curve = new THREE.CubicBezierCurve3(
    new THREE.Vector3(...entrance.origin, 0),
    new THREE.Vector3(...entrance.handle, 0),
    new THREE.Vector3(first.x - first.tx * 260, first.y - first.ty * 260, 0),
    new THREE.Vector3(first.x, first.y, 0),
  );
  ribbon.feedLength = curve.getLength();
  ribbon.feedSamples = curve.getSpacedPoints(300);
}

function threadPoint(ribbon, distance) {
  if (distance >= 0) return ribbon.at(distance);
  const samples = ribbon.feedSamples;
  const position = (distance + ribbon.feedLength) / ribbon.feedLength * 300;
  if (position <= 0) {
    const dx = samples[1].x - samples[0].x;
    const dy = samples[1].y - samples[0].y;
    const magnitude = Math.hypot(dx, dy);
    const tx = dx / magnitude;
    const ty = dy / magnitude;
    const extension = distance + ribbon.feedLength;
    return {x: samples[0].x + tx * extension, y: samples[0].y + ty * extension, tx, ty};
  }
  const index = Math.min(299, Math.floor(position));
  const mix = position - index;
  const a = samples[index];
  const b = samples[index + 1];
  const magnitude = Math.hypot(b.x - a.x, b.y - a.y);
  return {x: a.x + (b.x - a.x) * mix, y: a.y + (b.y - a.y) * mix, tx: (b.x - a.x) / magnitude, ty: (b.y - a.y) / magnitude};
}

function sourceLayers() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = SIZE;
  const context = canvas.getContext('2d', {willReadFrequently: true});
  context.drawImage(poster, 0, 0);
  const original = context.getImageData(0, 0, SIZE, SIZE);
  const images = Array.from({length: 8}, () => context.createImageData(SIZE, SIZE));
  // A coarse nearest-curve lookup avoids scanning every curve for every pixel.
  const stride = 8;
  const cells = SIZE / stride;
  const distances = ribbons.map(ribbon => {
    const field = new Float32Array(cells * cells);
    for (let y = 0; y < cells; y++) for (let x = 0; x < cells; x++) {
      field[y * cells + x] = ribbon.nearest(x * stride + stride / 2, y * stride + stride / 2).distance;
    }
    return field;
  });
  for (let y = 0; y < SIZE; y++) for (let x = 0; x < SIZE; x++) {
    const offset = (y * SIZE + x) * 4;
    const r = original.data[offset];
    const g = original.data[offset + 1];
    const b = original.data[offset + 2];
    const a = original.data[offset + 3];
    if (!a) continue;
    const cell = Math.floor(y / stride) * cells + Math.floor(x / stride);
    let layer;
    if (a < 220 && y > 920 && r + g + b < 320) {
      layer = 7;
    } else if (r - g > 27 && g - b > 20 && x > 520 && x < 802 && y > 460 && y < 733) {
      layer = 6;
    } else {
      const candidates = r - g > 4 ? [4, 5] : [0, 1, 2, 3];
      layer = candidates.reduce((best, id) => distances[id][cell] < distances[best][cell] ? id : best);
    }
    images[layer].data.set(original.data.subarray(offset, offset + 4), offset);
  }
  for (const ribbon of ribbons) {
    const depths = Array.from({length: 241}, (_, i) => {
      const point = ribbon.at(i / 240 * ribbon.length);
      const offset = (Math.round(point.y) * SIZE + Math.round(point.x)) * 4;
      return images[ribbon.index].data[offset + 3] > 120 ? 32 : -32;
    });
    ribbon.depths = depths.map((_, i) => {
      let total = 0;
      for (let j = -5; j <= 5; j++) total += depths[Math.max(0, Math.min(240, i + j))];
      return total / 11;
    });
  }
  return images.map(data => {
    const layer = document.createElement('canvas');
    layer.width = layer.height = SIZE;
    layer.getContext('2d').putImageData(data, 0, 0);
    const texture = new THREE.CanvasTexture(layer);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.generateMipmaps = false;
    texture.minFilter = THREE.LinearFilter;
    return texture;
  });
}

const scene = new THREE.Scene();
const camera = new THREE.OrthographicCamera(-1280, 1280, 1280, -1280, 0.1, 4000);
camera.position.z = 2000;

function buildSurface(ribbon, texture) {
  // A regular source grid has an identity transform at rest, including every
  // silhouette pixel, highlight, returned edge and overlap from the chosen art.
  const geometry = new THREE.PlaneGeometry(SIZE, SIZE);
  const positions = geometry.attributes.position;
  const source = positions.array.slice();
  const material = new THREE.MeshBasicMaterial({map: texture, transparent: true, depthWrite: false, depthTest: false, side: THREE.DoubleSide, toneMapped: false});
  const mesh = new THREE.Mesh(geometry, material);
  mesh.frustumCulled = false;
  mesh.renderOrder = 10 + ribbon.index;
  scene.add(mesh);
  return {mesh, source};
}

function buildBacking(ribbon, sourceTexture) {
  const segments = 280;
  const columns = 12;
  const extent = 195;
  const pad = 100;
  const count = (segments + 1) * (columns + 1);
  const positions = new Float32Array(count * 3);
  const uvs = new Float32Array(count * 2);
  const sourceUvs = new Float32Array(count * 2);
  const halfWidths = new Float32Array(count);
  const indices = [];
  for (let i = 0; i <= segments; i++) for (let j = 0; j <= columns; j++) {
    const vertex = i * (columns + 1) + j;
    const along = -pad + i / segments * (ribbon.length + 2 * pad);
    const source = ribbon.at(along);
    const normal = (j / columns * 2 - 1) * extent;
    uvs[vertex * 2] = i / segments;
    uvs[vertex * 2 + 1] = j / columns;
    sourceUvs[vertex * 2] = (source.x - source.ty * normal) / SIZE;
    sourceUvs[vertex * 2 + 1] = 1 - (source.y + source.tx * normal) / SIZE;
    if (i < segments && j < columns) {
      const a = vertex;
      const b = a + columns + 1;
      indices.push(a, b, a + 1, a + 1, b, b + 1);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geometry.setAttribute('sourceUv', new THREE.BufferAttribute(sourceUvs, 2));
  geometry.setAttribute('halfWidth', new THREE.BufferAttribute(halfWidths, 1));
  geometry.setIndex(indices);
  const material = new THREE.ShaderMaterial({
    transparent: true, depthWrite: true, side: THREE.DoubleSide, toneMapped: false,
    uniforms: {
      threadTexture: {value: completeThreadTexture(ribbon)},
      sourceTexture: {value: sourceTexture},
      sourceMix: {value: 0},
      layerOpacity: {value: 1},
      extent: {value: extent},
    },
    vertexShader: `
      attribute vec2 sourceUv;
      attribute float halfWidth;
      varying vec2 vUv;
      varying vec2 vSourceUv;
      varying float vHalfWidth;
      void main() {
        vUv = uv;
        vSourceUv = sourceUv;
        vHalfWidth = halfWidth;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform sampler2D threadTexture;
      uniform sampler2D sourceTexture;
      uniform float sourceMix;
      uniform float layerOpacity;
      uniform float extent;
      varying vec2 vUv;
      varying vec2 vSourceUv;
      varying float vHalfWidth;
      void main() {
        float normal = (vUv.y * 2.0 - 1.0) * extent;
        float bodyAlpha = (1.0 - smoothstep(vHalfWidth - 0.65, vHalfWidth + 0.65, abs(normal))) * step(0.5, vHalfWidth);
        vec2 bodyUv = vec2(vUv.x, normal / max(1.0, vHalfWidth * 2.0) + 0.5);
        vec4 body = texture2D(threadTexture, bodyUv);
        vec4 source = texture2D(sourceTexture, vSourceUv);
        if (vSourceUv.x < 0.0 || vSourceUv.x > 1.0 || vSourceUv.y < 0.0 || vSourceUv.y > 1.0) source.a = 0.0;
        float a = bodyAlpha * (1.0 - sourceMix) + source.a * sourceMix;
        if (a < 0.002) discard;
        vec3 color = (body.rgb * bodyAlpha * (1.0 - sourceMix) + source.rgb * source.a * sourceMix) / max(a, 0.001);
        gl_FragColor = vec4(color, a * layerOpacity);
        #include <colorspace_fragment>
      }
    `,
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.frustumCulled = false;
  mesh.renderOrder = 1 + ribbon.index;
  scene.add(mesh);
  return {mesh, segments, columns, extent, pad};
}

function completeThreadTexture(ribbon) {
  // Reconstruct occluded lengths as one matte surface. Repeating fragments of
  // the still would repeat its overlap shadows and make the entrance look torn.
  const width = 384;
  const height = 96;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  const pixels = context.createImageData(width, height);
  const base = ribbon.index < 4 ? [123, 130, 108] : ribbon.index < 6 ? [224, 215, 198] : [200, 134, 95];
  let seed = 1837 + ribbon.index;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const across = y / (height - 1);
    const along = x / (width - 1);
    const face = 0.96 + 0.055 * Math.sin(across * Math.PI) - 0.055 * across;
    const edge = across < 0.045 ? 0.86 + across * 3 : across > 0.91 ? 0.94 - (across - 0.91) * 2.2 : 1;
    const light = 0.91 + 0.07 * Math.sin(along * Math.PI * 2 + ribbon.index * 0.7);
    seed = (1664525 * seed + 1013904223) >>> 0;
    const grain = ((seed >>> 24) / 255 - 0.5) * 4;
    const offset = (y * width + x) * 4;
    for (let channel = 0; channel < 3; channel++) pixels.data[offset + channel] = base[channel] * face * edge * light + grain;
    pixels.data[offset + 3] = 255;
  }
  context.putImageData(pixels, 0, 0);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function updateRibbon(ribbon, milliseconds) {
  const linear = clamp((milliseconds - ribbon.start) / ribbon.duration);
  const travel = smooth(linear);
  const head = -ribbon.feedLength + (ribbon.feedLength + ribbon.length) * travel;
  const tail = head - ribbon.length;
  // Restore the source shading on the SAME moving surface, avoiding a double
  // silhouette. A final, stationary pixel pass only closes any sampling seams.
  const sourceMix = smooth((linear - 0.82) / 0.18);
  const finishMix = smooth((milliseconds - 6580) / 150);
  ribbon.surface.mesh.visible = finishMix > 0;
  ribbon.surface.mesh.material.opacity = finishMix;
  const backing = ribbon.backing;
  backing.mesh.visible = linear > 0 && finishMix < 1;
  backing.mesh.material.uniforms.sourceMix.value = sourceMix;
  backing.mesh.material.uniforms.layerOpacity.value = 1 - finishMix;
  backing.mesh.material.depthWrite = sourceMix < 0.01;
  backing.mesh.material.depthTest = sourceMix < 0.01;
  const positions = backing.mesh.geometry.attributes.position;
  const halfWidths = backing.mesh.geometry.attributes.halfWidth;
  const widthSettled = smooth((linear - 0.7) / 0.3);
  for (let i = 0; i <= backing.segments; i++) {
    const sourceDistance = -backing.pad + i / backing.segments * (ribbon.length + backing.pad * 2);
    const distance = tail + sourceDistance;
    const center = threadPoint(ribbon, distance);
    if (sourceDistance < 0 || sourceDistance > ribbon.length) {
      const target = ribbon.at(sourceDistance);
      const align = smooth((linear - 0.85) / 0.15);
      center.x += (target.x - center.x) * align;
      center.y += (target.y - center.y) * align;
      center.tx += (target.tx - center.tx) * align;
      center.ty += (target.ty - center.ty) * align;
    }
    const feedingWidth = 0.2 + 0.8 * smooth((distance + 50) / 340);
    const idealWidth = ribbon.width * (feedingWidth + (1 - feedingWidth) * widthSettled);
    const previous = threadPoint(ribbon, distance - 8);
    const next = threadPoint(ribbon, distance + 8);
    const curvature = Math.abs(Math.atan2(previous.tx * next.ty - previous.ty * next.tx, previous.tx * next.tx + previous.ty * next.ty)) / 16;
    const width = Math.min(idealWidth, 1.65 / Math.max(curvature, 0.0001));
    const depthIndex = Math.max(0, Math.min(239.99, distance / ribbon.length * 240));
    const depthA = Math.floor(depthIndex);
    const depth = distance < 0 ? ribbon.index * 0.1 : ribbon.depths[depthA] + (ribbon.depths[depthA + 1] - ribbon.depths[depthA]) * (depthIndex - depthA);
    const endRound = Math.sqrt(Math.max(0, Math.min(1, sourceDistance / 18, (ribbon.length - sourceDistance) / (18 + 46 * (1 - widthSettled)))));
    for (let j = 0; j <= backing.columns; j++) {
      const normal = (j / backing.columns * 2 - 1) * backing.extent;
      const x = center.x - center.ty * normal;
      const y = center.y + center.tx * normal;
      const vertex = i * (backing.columns + 1) + j;
      positions.setXYZ(vertex, x - 640, 640 - y, depth);
      halfWidths.setX(vertex, width * endRound * 0.5);
    }
  }
  positions.needsUpdate = true;
  halfWidths.needsUpdate = true;
}

let shadow;
function render(milliseconds) {
  elapsed = Math.max(0, Math.min(DURATION, milliseconds));
  if (!renderer) return;
  const choreographyTime = elapsed / DURATION * CHOREOGRAPHY_DURATION;
  for (const ribbon of ribbons) updateRibbon(ribbon, choreographyTime);
  shadow.material.opacity = smooth((choreographyTime - 5520) / 1160);
  renderer.render(scene, camera);
  // Traced ribbons seat first; a short surface blend restores the source detail.
  // The immutable poster holds the exact approved artwork after the motion.
  const complete = elapsed >= 995;
  poster.hidden = !complete && !referenceVisible;
  renderer.domElement.hidden = complete || referenceVisible;
  progress.value = String(Math.round(elapsed));
  timeLabel.textContent = `${(elapsed / 1000).toFixed(1)} / 1.0 s`;
  stage.dataset.progress = String(Math.round(elapsed));
  stage.dataset.state = complete ? 'complete' : playing ? 'playing' : 'paused';
  if (referenceVisible) status.textContent = 'The original selected artwork';
  else if (playing) status.textContent = choreographyTime < 1900 ? 'Threads converge from every side' : choreographyTime < 3960 ? 'Over, under, together' : choreographyTime < 5700 ? 'Bind the center' : 'Settle into the original weave';
}
function pause() {
  playing = false;
  cancelAnimationFrame(frame);
  toggle.textContent = 'Play';
}
function finish() {
  pause();
  referenceVisible = false;
  referenceButton.setAttribute('aria-pressed', 'false');
  render(DURATION);
  status.textContent = reduce() ? 'Reduced motion · original artwork' : 'Original artwork · holds still';
}
function tick(now) {
  if (!playing) return;
  if (!startedAt) startedAt = now;
  render(startElapsed + now - startedAt);
  if (elapsed >= DURATION) finish();
  else frame = requestAnimationFrame(tick);
}
function play(restart = false) {
  pause();
  if (reduce()) { finish(); return; }
  referenceVisible = false;
  referenceButton.setAttribute('aria-pressed', 'false');
  if (restart || elapsed >= DURATION) elapsed = 0;
  playing = true;
  startedAt = 0;
  startElapsed = elapsed;
  toggle.textContent = 'Pause';
  frame = requestAnimationFrame(tick);
}
function changePreference() {
  for (const control of [progress, replay, toggle]) control.disabled = reduce();
  if (reduce()) finish();
  else status.textContent = elapsed >= DURATION ? 'Original artwork · holds still' : 'Paused · inspect the weave';
}
replay.addEventListener('click', () => play(true));
toggle.addEventListener('click', () => { if (playing) { pause(); status.textContent = 'Paused'; } else play(); });
finalButton.addEventListener('click', finish);
referenceButton.addEventListener('click', () => {
  pause();
  referenceVisible = !referenceVisible;
  referenceButton.setAttribute('aria-pressed', String(referenceVisible));
  render(elapsed);
  if (!referenceVisible) status.textContent = 'Paused · inspect the weave';
});
progress.addEventListener('input', () => {
  pause(); referenceVisible = false;
  referenceButton.setAttribute('aria-pressed', 'false');
  render(Number(progress.value)); status.textContent = elapsed >= 995 ? 'Original artwork · holds still' : 'Paused · inspect the weave';
});
reducePreview.addEventListener('change', changePreference);
reduced.addEventListener('change', changePreference);

async function initialize() {
  await poster.decode();
  renderer = new THREE.WebGLRenderer({alpha: true, antialias: true, powerPreference: 'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.setClearColor(0, 0);
  renderer.domElement.className = 'woven-canvas';
  renderer.domElement.setAttribute('aria-hidden', 'true');
  stage.append(renderer.domElement);
  const textures = sourceLayers();
  for (const ribbon of ribbons) {
    ribbon.surface = buildSurface(ribbon, textures[ribbon.index]);
    ribbon.backing = buildBacking(ribbon, textures[ribbon.index]);
  }
  shadow = new THREE.Mesh(new THREE.PlaneGeometry(SIZE, SIZE), new THREE.MeshBasicMaterial({map: textures[7], transparent: true, depthWrite: false, toneMapped: false}));
  scene.add(shadow);
  const resize = () => {
    renderer.setSize(stage.clientWidth * 2, stage.clientWidth * 2, false);
    render(elapsed);
  };
  const observer = new ResizeObserver(resize);
  observer.observe(stage);
  document.addEventListener('visibilitychange', () => { if (document.hidden && playing) finish(); });
  renderer.domElement.addEventListener('webglcontextlost', event => {
    event.preventDefault(); pause(); poster.hidden = false; renderer.domElement.hidden = true;
    status.textContent = 'Showing the original artwork';
  });
  window.addEventListener('pagehide', () => { pause(); observer.disconnect(); renderer.dispose(); }, {once: true});
  resize();
  changePreference();
  if (document.hidden || reduce()) finish();
  else play(true);
}
initialize().catch(error => {
  pause();
  poster.hidden = false;
  if (renderer) renderer.domElement.hidden = true;
  status.textContent = 'Showing the original artwork';
  console.error('Artwork motion unavailable', error);
});
