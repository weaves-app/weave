// Offline export helper. No package or part of this page ships in the app.
function concatenate(parts) {
  const result = new Uint8Array(parts.reduce((size, part) => size + part.length, 0));
  let offset = 0;
  for (const part of parts) { result.set(part, offset); offset += part.length; }
  return result;
}

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function archiveFrames(files) {
  const locals = [];
  const central = [];
  let offset = 0;
  for (const file of files) {
    const name = new TextEncoder().encode(file.name);
    const crc = crc32(file.bytes);
    const local = new Uint8Array(30 + name.length);
    const header = new DataView(local.buffer);
    header.setUint32(0, 0x04034b50, true);
    header.setUint16(4, 20, true);
    header.setUint32(14, crc, true);
    header.setUint32(18, file.bytes.length, true);
    header.setUint32(22, file.bytes.length, true);
    header.setUint16(26, name.length, true);
    local.set(name, 30);
    locals.push(local, file.bytes);
    const index = new Uint8Array(46 + name.length);
    const view = new DataView(index.buffer);
    view.setUint32(0, 0x02014b50, true);
    view.setUint16(4, 20, true);
    view.setUint16(6, 20, true);
    view.setUint32(16, crc, true);
    view.setUint32(20, file.bytes.length, true);
    view.setUint32(24, file.bytes.length, true);
    view.setUint16(28, name.length, true);
    view.setUint32(42, offset, true);
    index.set(name, 46);
    central.push(index);
    offset += local.length + file.bytes.length;
  }
  const directory = concatenate(central);
  const end = new Uint8Array(22);
  const view = new DataView(end.buffer);
  view.setUint32(0, 0x06054b50, true);
  view.setUint16(8, files.length, true);
  view.setUint16(10, files.length, true);
  view.setUint32(12, directory.length, true);
  view.setUint32(16, offset, true);
  return new Blob([...locals, directory, end], {type: 'application/zip'});
}

document.getElementById('export-master').addEventListener('click', async event => {
  const button = event.currentTarget;
  button.disabled = true;
  pause();
  referenceVisible = false;
  const size = 1600;
  renderer.setPixelRatio(1);
  renderer.setSize(size, size, false);
  const master = document.createElement('canvas');
  master.width = master.height = size;
  const context = master.getContext('2d');
  const frames = [];
  try {
    for (let frame = 0; frame < 60; frame++) {
      render(frame === 59 ? 1000 : frame * 1000 / 60);
      context.clearRect(0, 0, size, size);
      context.fillStyle = '#D9C9B2';
      context.fillRect(0, 0, size, size);
      if (frame === 59) context.drawImage(poster, size / 4, size / 4, size / 2, size / 2);
      else context.drawImage(renderer.domElement, 0, 0, size, size);
      const blob = await new Promise(resolve => master.toBlob(resolve, 'image/png'));
      frames.push({name: `frame-${String(frame).padStart(3, '0')}.png`, bytes: new Uint8Array(await blob.arrayBuffer())});
      status.textContent = `Exporting master frame ${frame + 1} / 60`;
    }
    const archive = archiveFrames(frames);
    const url = URL.createObjectURL(archive);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'woven-master-1600-60fps.zip';
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    status.textContent = '60 lossless master frames exported';
  } catch (error) {
    status.textContent = `Export failed: ${String(error)}`;
  } finally {
    button.disabled = false;
  }
});
