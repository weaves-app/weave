import * as THREE from '../assets/vendor/three.module.js';
// Guides are authored in the approved 1280 × 1280 image coordinate system.
// Their asymmetric curves and returned ends belong to the original sculpture.
const definitions = [
  { name: 'Olive upper cross-thread', color: '#737a61', width: 144, start: 0, duration: 4800,
    points: [[125,634],[216,636],[354,518],[470,464],[573,388],[671,307]] },
  { name: 'Olive upper down-thread', color: '#737a61', width: 143, start: 70, duration: 4850,
    points: [[596,124],[640,204],[744,288],[804,410],[855,531],[959,639],[1005,727],[977,764]] },
  { name: 'Olive lower down-thread', color: '#747b61', width: 143, start: 120, duration: 4800,
    points: [[366,570],[420,637],[511,766],[602,919],[701,1010],[755,1086],[720,1123]] },
  { name: 'Olive lower cross-thread', color: '#757d63', width: 141, start: 180, duration: 4750,
    points: [[1159,553],[1117,630],[965,738],[818,808],[661,865],[553,921],[529,972],[574,1003]] },
  { name: 'Ivory descending thread', color: '#ded3bd', width: 164, start: 240, duration: 4790,
    points: [[365,386],[356,322],[420,310],[523,407],[611,529],[701,661],[818,804],[916,914],[986,938]] },
  { name: 'Ivory returning thread', color: '#ded3bd', width: 160, start: 310, duration: 4800,
    points: [[503,965],[412,951],[342,885],[357,816],[486,725],[634,631],[798,514],[936,403],[965,354],[928,335]] },
  { name: 'Terracotta binding', color: '#bd7954', width: 124, start: 900, duration: 4200,
    points: [[611,673],[586,620],[628,581],[684,548],[728,548],[753,580]] },
];

function trace(points) {
  const curve = new THREE.CatmullRomCurve3(points.map(([x, y]) => new THREE.Vector3(x, y, 0)), false, 'centripetal');
  const samples = curve.getSpacedPoints(240);
  const length = curve.getLength();
  function at(distance) {
    const t = distance / length;
    if (t < 0 || t > 1) {
      const end = t < 0 ? 0 : samples.length - 1;
      const adjacent = t < 0 ? 1 : samples.length - 2;
      const direction = samples[end].clone().sub(samples[adjacent]).normalize();
      const extension = t < 0 ? -distance : distance - length;
      const point = samples[end].clone().addScaledVector(direction, extension);
      return { x: point.x, y: point.y, tx: t < 0 ? -direction.x : direction.x, ty: t < 0 ? -direction.y : direction.y };
    }
    const index = Math.min(samples.length - 2, Math.floor(t * (samples.length - 1)));
    const fraction = t * (samples.length - 1) - index;
    const a = samples[index];
    const b = samples[index + 1];
    const d = Math.hypot(b.x - a.x, b.y - a.y);
    return {x: a.x + (b.x - a.x) * fraction, y: a.y + (b.y - a.y) * fraction, tx: (b.x - a.x) / d, ty: (b.y - a.y) / d};
  }
  function nearest(x, y) {
    let distance = Infinity;
    let index = 0;
    for (let j = 0; j < samples.length; j++) {
      const p = samples[j];
      const d = (p.x - x) ** 2 + (p.y - y) ** 2;
      if (d < distance) { distance = d; index = j; }
    }
    return {distance, along: index / (samples.length - 1) * length};
  }
  return {at, nearest, length};
}
// Feed each end from the edge that naturally continues its final tangent.
// Reversing traversal changes the entrance, not the final ribbon geometry.
definitions[2].points.reverse();
definitions[4].points.reverse();
definitions[5].points.reverse();
const entrances = [
  {side: 'left', origin: [-520, 640], handle: [-110, 625]},
  {side: 'top', origin: [565, -520], handle: [550, -110]},
  {side: 'bottom', origin: [695, 1800], handle: [705, 1400]},
  {side: 'right', origin: [1800, 550], handle: [1420, 565]},
  {side: 'bottom-right', origin: [1770, 1740], handle: [1350, 1230]},
  {side: 'top-right', origin: [1720, -480], handle: [1230, 25]},
  {side: 'top-left', origin: [-480, -450], handle: [130, 190]},
];
const ribbons = definitions.map((definition, index) => ({...definition, index, ...trace(definition.points)}));

for (const ribbon of ribbons) {
  const first = ribbon.at(0);
  const entrance = entrances[ribbon.index];
  const curve = new THREE.CubicBezierCurve3(
    new THREE.Vector3(...entrance.origin, 0),
    new THREE.Vector3(...entrance.handle, 0),
    new THREE.Vector3(first.x - first.tx * 260, first.y - first.ty * 260, 0),
    new THREE.Vector3(first.x, first.y, 0),
  );
  ribbon.feedLength = curve.getLength();
  ribbon.feedSamples = curve.getSpacedPoints(300);
}

function threadPoint(ribbon, distance) {
  if (distance >= 0) return ribbon.at(distance);
  const samples = ribbon.feedSamples;
  const position = (distance + ribbon.feedLength) / ribbon.feedLength * 300;
  if (position <= 0) {
    const dx = samples[1].x - samples[0].x;
    const dy = samples[1].y - samples[0].y;
    const magnitude = Math.hypot(dx, dy);
    const tx = dx / magnitude;
    const ty = dy / magnitude;
    const extension = distance + ribbon.feedLength;
    return {x: samples[0].x + tx * extension, y: samples[0].y + ty * extension, tx, ty};
  }
  const index = Math.min(299, Math.floor(position));
  const mix = position - index;
  const a = samples[index];
  const b = samples[index + 1];
  const magnitude = Math.hypot(b.x - a.x, b.y - a.y);
  return {x: a.x + (b.x - a.x) * mix, y: a.y + (b.y - a.y) * mix, tx: (b.x - a.x) / magnitude, ty: (b.y - a.y) / magnitude};
}


export {ribbons, threadPoint};
